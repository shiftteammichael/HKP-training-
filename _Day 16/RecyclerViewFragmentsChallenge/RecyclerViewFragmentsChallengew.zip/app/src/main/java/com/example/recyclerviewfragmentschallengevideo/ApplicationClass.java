package com.example.recyclerviewfragmentschallengevideo;

import android.app.Application;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class ApplicationClass extends Application {
    public static ArrayList<Car> cars;

    @Override
    public void onCreate() {
        super.onCreate();

        cars = new ArrayList<Car>();
        cars.add(new Car("volkswagen","Polo","Chuck Norris","091229239329239"));
        cars.add(new Car("volkswagen","Fire","MIKE Norris","091229239329239"));
        cars.add(new Car("nissan","E200","SIKE Norris","091229239329239"));
        cars.add(new Car("mercedes","Polo","Chuck Norris","091229239329239"));
        cars.add(new Car("mercedes","Black","Borris Lorris","091229239329239"));
        cars.add(new Car("nissan","yerrr","hi Norris","091229239329239"));
    }
}

