package com.example.recycleview;

public class Person {
    private String name;
    private String surname;
    private String preference;

    public Person(String name, String surname,String preference) {
        this.preference = preference;
        this.name=name;
        this.surname=surname;
    }

    public String getPreference() {
        return preference;
    }

    public void setPreference(String preference) {
        this.preference = preference;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
