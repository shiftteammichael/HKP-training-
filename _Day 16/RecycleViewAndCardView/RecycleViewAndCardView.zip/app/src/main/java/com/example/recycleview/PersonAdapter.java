package com.example.recycleview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PersonAdapter extends RecyclerView.Adapter<PersonAdapter.ViewHolder> {
    private ArrayList<Person>people;
    ItemClicked activity;
    public interface ItemClicked{
        void onItemClicked(int index);
    }

    public PersonAdapter(Context context, ArrayList<Person> list){
        people=list;
        activity= (ItemClicked) context;
    }
    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageView ivPic;
        TextView tvName,tvSurname;
        public ViewHolder (View itemView){
            super(itemView);
            tvName=itemView.findViewById(R.id.tvName);
            tvSurname=itemView.findViewById(R.id.tvSurname);
            ivPic=itemView.findViewById(R.id.ivPic);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    activity.onItemClicked(people.indexOf((Person)v.getTag()));
                }
            });
        }
    }
    @NonNull
    @Override
    public PersonAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_items,viewGroup,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull PersonAdapter.ViewHolder viewHolder, int position) {
        viewHolder.itemView.setTag(people.get(position));

        viewHolder.tvName.setText(people.get(position).getName());
        viewHolder.tvSurname.setText(people.get(position).getSurname());

        if(people.get(position).getPreference().equals("bus")){
            viewHolder.ivPic.setImageResource(R.drawable.bus);
        }
        else{
            viewHolder.ivPic.setImageResource(R.drawable.plane);
        }
    }

    @Override
    public int getItemCount() {
        return people.size();
    }
}
