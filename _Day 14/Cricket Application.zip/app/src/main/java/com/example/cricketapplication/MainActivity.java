package com.example.cricketapplication;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText etID;
    Button btn;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);


        etID=findViewById(R.id.etID);
        btn=findViewById(R.id.btn);
        textView=findViewById(R.id.textView);
        textView.setVisibility(View.GONE);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String getChirps= etID.getText().toString();
                double chirps=Double.parseDouble(getChirps);
                double answer = (chirps/3)+4;

                String text="The approximate temperature outside is "+answer+ " degrees Celcius";
                textView.setText(text);
                textView.setVisibility(View.VISIBLE);
            }
        });

    }
}