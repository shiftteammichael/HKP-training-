package com.example.idapplication;

import android.annotation.SuppressLint;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText etId;
    Button btnSubmit;
    TextView tvResults;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etId=findViewById(R.id.etID);
        btnSubmit=findViewById(R.id.btnSubmit);
        tvResults=findViewById(R.id.tvResults);

        btnSubmit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String idNumber=etId.getText().toString().trim();
                String dob= idNumber.substring(0,6);
                int gender=Integer.parseInt(Character.toString(idNumber.charAt(6)));
                String sGender;
                if(gender<5){
                    sGender="Female";
                }
                else{
                    sGender="Male";
                }
                int nationality=Integer.parseInt(Character.toString(idNumber.charAt(10)));
                String sNationality;
                if(nationality==0){
                    sNationality="SA Citizen";
                }else{
                    sNationality="Permanent Resident";
                }
                String text=getString(R.string.dob)+dob+ getString(R.string.gender)+ sGender+ getString(R.string.nationality)+sNationality;
                tvResults.setText(text);
            }
        });
    }
}