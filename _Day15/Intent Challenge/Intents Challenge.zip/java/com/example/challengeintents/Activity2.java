package com.example.challengeintents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class Activity2 extends AppCompatActivity {
    EditText etNumber,etName,etWeb,etLocation;
    ImageView imgViewSad,imgViewHappy,imgViewYes;
    int  Activity3=4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        etNumber=findViewById(R.id.etNumber);
        etName=findViewById(R.id.etName);
        etWeb=findViewById(R.id.etWeb);
        etLocation=findViewById(R.id.etLocation);
        imgViewHappy=findViewById(R.id.imgViewHappy);
        imgViewSad=findViewById(R.id.imgViewSad);
        imgViewYes=findViewById(R.id.imgViewYes);

        imgViewHappy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etName.getText().toString().isEmpty() || etNumber.getText().toString().isEmpty()||etWeb.getText().toString().isEmpty()||etLocation.getText().toString().isEmpty()){
                    Toast.makeText(Activity2.this,"Please enter all fields!",Toast.LENGTH_SHORT).show();
                }
                else{
                    String name= etName.getText().toString();
                    String number= etNumber.getText().toString();
                    String web=etWeb.getText().toString();
                    String location=etLocation.getText().toString();
                    Intent intent=new Intent(Activity2.this, com.example.challengeintents.Activity3.class);
                    intent.putExtra("name",name);
                    intent.putExtra("number",number);
                    intent.putExtra("web",web);
                    intent.putExtra("location",location);
                    intent.putExtra("mood","happy");
                    startActivity(intent);
                }
            }
        });
        imgViewSad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etName.getText().toString().isEmpty() || etNumber.getText().toString().isEmpty()||etWeb.getText().toString().isEmpty()||etLocation.getText().toString().isEmpty()){
                    Toast.makeText(Activity2.this,"Please enter all fields!",Toast.LENGTH_SHORT).show();
                }
                else{
                    String name= etName.getText().toString();
                    String number= etNumber.getText().toString();
                    String web=etWeb.getText().toString();
                    String location=etLocation.getText().toString();
                    Intent intent=new Intent(Activity2.this, com.example.challengeintents.Activity3.class);
                    intent.putExtra("name",name);
                    intent.putExtra("number",number);
                    intent.putExtra("web",web);
                    intent.putExtra("location",location);
                    intent.putExtra("mood","Sad");
                    startActivity(intent);
                }
            }
        });
        imgViewYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etName.getText().toString().isEmpty() || etNumber.getText().toString().isEmpty()||etWeb.getText().toString().isEmpty()||etLocation.getText().toString().isEmpty()){
                    Toast.makeText(Activity2.this,"Please enter all fields!",Toast.LENGTH_SHORT).show();
                }
                else{
                    String name= etName.getText().toString();
                    String number= etNumber.getText().toString();
                    String web=etWeb.getText().toString();
                    String location=etLocation.getText().toString();
                    Intent intent=new Intent(Activity2.this, com.example.challengeintents.Activity3.class);
                    intent.putExtra("name",name);
                    intent.putExtra("number",number);
                    intent.putExtra("web",web);
                    intent.putExtra("location",location);
                    intent.putExtra("mood","yes");
                    startActivity(intent);
                }
            }
        });
    }
}