package com.example.challengeintents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Activity3 extends AppCompatActivity {
    ImageView weber,locationr,phoner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);
        weber=findViewById(R.id.web);
        locationr=findViewById(R.id.location);
        phoner=findViewById(R.id.phone1);

        weber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String web1=getIntent().getStringExtra("web");
                Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse("https://" +web1));
                startActivity(intent);
            }
        });
        locationr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String location1=getIntent().getStringExtra("location");
                Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q="+location1));
                startActivity(intent);
            }
        });
        phoner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone2=getIntent().getStringExtra("number");
                Intent intent=new Intent(Intent.ACTION_DIAL,Uri.parse(phone2));
                startActivity(intent);
            }
        });
    }
}