package com.raywenderlich.android.rwandroidtutorial

enum class WeatherState { SUN, RAIN }